import express from "express";
import OpenAI from "openai";

const app = express();
const port = process.env.PORT || 3000;

app.use(express.json({ limit: "10kb" }));
app.use(express.static("public"));

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

// Limitación sencilla por IP para reducir abuso. Para producción, usa un limitador
// persistente y reglas adicionales en el proveedor de alojamiento.
const hits = new Map();
app.use("/api/", (req, res, next) => {
  const key = req.ip || "unknown";
  const now = Date.now();
  const previous = hits.get(key) || { count: 0, start: now };
  if (now - previous.start > 60_000) {
    previous.count = 0;
    previous.start = now;
  }
  previous.count += 1;
  hits.set(key, previous);
  if (previous.count > 20) return res.status(429).json({ error: "Has enviado muchos mensajes. Espera un minuto e inténtalo de nuevo." });
  next();
});

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, aiConfigured: Boolean(process.env.OPENAI_API_KEY) });
});

app.post("/api/chat", async (req, res) => {
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message) return res.status(400).json({ error: "Escribe un mensaje." });
    if (message.length > 2000) return res.status(413).json({ error: "El mensaje es demasiado largo. Usa hasta 2000 caracteres." });
    if (!process.env.OPENAI_API_KEY) {
      return res.status(503).json({ error: "La IA todavía no está configurada en el servidor." });
    }

    // No guardamos el contenido del mensaje en registros de aplicación.
    const response = await openai.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-astra",
      instructions: `Eres EcoPsicología, un asistente de apoyo emocional en español.
Responde con empatía, sin juzgar, con lenguaje sencillo y consejos concretos y pequeños.
Puedes orientar sobre relaciones, rupturas, familia, finanzas personales, trabajo, estudios y autoestima.
No diagnostiques, no afirmes ser psicólogo ni sustituyas atención profesional.
No prometas confidencialidad absoluta. Anima a compartir solo lo necesario.
Para asuntos económicos, ofrece educación general, no prometas resultados.
No fomentes dependencia del asistente; anima a buscar apoyo de personas de confianza y profesionales.
Si detectas suicidio, autolesión, intención de morir o peligro inmediato, prioriza la seguridad:
expresa preocupación, pregunta si está en peligro inmediato, pide que no se quede a solas,
que se aleje de medios de daño, que contacte ahora a una persona de confianza y a los servicios
locales de emergencia o acuda a urgencias. No dependas de la IA como único recurso de crisis.
No inventes números telefónicos de emergencia. Mantén la respuesta clara y breve.`,
      input: message
    });

    res.json({ reply: response.output_text || "No pude generar una respuesta. Inténtalo de nuevo." });
  } catch (error) {
    console.error("Fallo de API de IA:", error?.status || error?.name || "error");
    res.status(500).json({ error: "No pude responder ahora. Inténtalo de nuevo en unos momentos." });
  }
});

app.listen(port, "0.0.0.0", () => {
  console.log(`EcoPsicología escuchando en el puerto ${port}`);
});
