# EcoPsicología: prototipo con servidor de IA

## Archivos
- `public/index.html`: interfaz para Android y computadora.
- `server.js`: servidor Express y endpoint `/api/chat`.
- `package.json`: dependencias y comando de inicio.

## Despliegue recomendado
1. Sube estos archivos a un repositorio privado de GitHub.
2. En Render crea `New` -> `Web Service` y conecta ese repositorio.
3. Runtime: Node. Build command: `npm install`. Start command: `npm start`.
4. En `Environment` añade `OPENAI_API_KEY` con tu clave secreta y, opcionalmente, `OPENAI_MODEL` con un modelo disponible en tu cuenta.
5. Despliega y abre la URL HTTPS que te entregue Render.

Nunca pongas la clave de API en `public/index.html`, en GitHub, ni la compartas en el chat. La API puede generar cargos y requiere configurar facturación/límites en el proveedor.

## Prueba
Abre `https://TU-SERVICIO/api/health`. Debe devolver JSON con `ok: true` y `aiConfigured: true`. Después abre la URL principal y envía un mensaje.

## Importante antes de publicar a otras personas
Este prototipo no es un servicio clínico ni de emergencias. No está auditado para uso de alto riesgo. Antes de un lanzamiento público, añade revisión profesional, una política de privacidad, consentimiento informado, controles contra abuso, protección de datos, límites de coste y un plan de respuesta a crisis. Verifica los recursos locales de emergencia en cada país; no inventes números.
